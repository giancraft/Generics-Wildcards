package wildcardUnbounded;

import java.util.List;

public class MostraQualquer {
	public static List<?> mostra(List<?> lista) {
		return lista;
	}
}
