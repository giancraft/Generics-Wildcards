package wildcardLowerBounded;

import java.util.List;

public class MostraIntegerOuSuper {
	
	public static List<? super Integer> mostra(List<? super Integer> lista) {
		return lista;
	}
}
